<?php

// uncomment the following to define a path alias
// Yii::setPathOfAlias('local','path/to/local-folder');

// This is the main Web application configuration. Any writable
// CWebApplication properties can be configured here.
//$app = file_get_contents('../common/.current');
$app = basename(dirname(dirname(__DIR__)));
return array(
    //'timeZone' => 'Asia/Dubai',
    'basePath' => dirname(__FILE__) . DIRECTORY_SEPARATOR . '..',
    'defaultController'=>'home',
    'name' => 'My Web Application',
    // preloading 'log' component
    'preload' => array('log'),
    'aliases' => array(
        'bootstrap' => realpath(__DIR__ . '/../extensions/bootstrap'), // change this if necessary
    ),
    'onBeginRequest' => function ($event) {
        VerifySSOToken::verify();
    },
    // autoloading model and component classes
    'import' => array(
        'application.models.*',
        'application.components.*',
        'bootstrap.helpers.TbHtml',
        'bootstrap.helpers.TbArray',
        'bootstrap.behaviors.TbWidget',
        'bootstrap.widgets.*',
        'ext.YiiMailer.YiiMailer'
    ),
    'modules' => array(
        // uncomment the following to enable the Gii tool
        'gii' => array(
            'class' => 'system.gii.GiiModule',
            'password' => 'abc@123',
            'ipFilters' => array('127.0.0.1', '::1'),
            'generatorPaths' => array('bootstrap.gii'),
        ),
        'api',
        'neteller',
        'admin' => array(
            'defaultController' => 'home'
        ),
    ),

    // application components
    'components' => array(
        'ePdf' => array(
            'class'         => 'ext.yii-pdf.EYiiPdf',
            'params'        => array(
                'mpdf'     => array(
                    'librarySourcePath' => 'application.vendors.mpdf.*',
                    'constants'         => array(
                        '_MPDF_TEMP_PATH' => Yii::getPathOfAlias('application.runtime'),
                    ),
                    'class'=>'mpdf',
                ),
                'HTML2PDF' => array(
                    'librarySourcePath' => 'application.vendors.html2pdf.*',
                    'classFile'         => 'html2pdf.class.php', // For adding to Yii::$classMap
                )
            ),
        ),
        /*'VerifySSOToken' => [
            'class'=>'app\components\VerifySSOToken'
        ],*/
        'session' => array(
            'class' => 'system.web.CDbHttpSession',
            'connectionID' => 'db',
            'timeout' => 14400,
            'autoCreateSessionTable' => true
        ),
        'user' => array(
            // enable cookie-based authentication
            'allowAutoLogin' => true,
            'loginUrl'=>array('home/login'),
        ),
        /*'request'=>array(
            'enableCsrfValidation'=>true,
        ),*/
        // uncomment the following to enable URLs in path-format
        'urlManager' => array(
            'urlFormat' => 'path',
            'showScriptName' => false,
            'useStrictParsing' => true,
            'rules' => array(
                //need to allow for gii in local
                'gii'=>'gii',
                'gii/<controller:\w+>'=>'gii/<controller>',
                'gii/<controller:\w+>/<action:\w+>'=>'gii/<controller>/<action>',
                //'home/signup/<id:\d+>'=>'home/signup/',
                /*'<module:\w+>/<controller:\w+>/<id:\d+>'=>'<module>/<controller>/view',*/
                '<controller:\w+>/<action:\w+>/<id:\d+>' => '<controller>/<action>',
                '<module:\w+>/<controller:\w+>/<action:\w+>'=>'<module>/<controller>/<action>',
                '<module:\w+>/<controller:\w+>/<action:\w+>/<id:\d+>'=>'<module>/<controller>/<action>',
                /*'<controller:\w+>/<id:\d+>' => '<controller>/view',*/
                /*'<controller:\w+>/<action:\w+>/<category:\w+>' => '<controller>/<action>',*/
                '<controller:\w+>/<action:\w+>' => '<controller>/<action>',
            ),
        ),
        /*'bootstrap' => array(
            'class' => 'bootstrap.components.TbApi'
        ),*/
        /*'bootstrap' => [
            'VerifySSOToken'
        ],*/
        // database settings are configured in database.php
        'db' => require("db.php"),
        'sitedb' => require("db.php"),

        'ServiceHelper' => array(
            'class' => 'application.components.ServiceHelper',
        ),
        'errorHandler' => array(
            // use 'site/error' action to display errors
            //'errorAction' => YII_DEBUG ? null : 'admin/error',
        ),

        'log' => array(
            'class' => 'CLogRouter',
            'routes' => array(
                array(
                    'class' => 'CFileLogRoute',
                    'levels' => 'error, warning',
                ),
                // uncomment the following to show log messages on web pages
                /*
                array(
                    'class'=>'CWebLogRoute',
                ),
                */
            ),
        ),
        'mail' => require("mail.php")
    ),

    // application-level parameters that can be accessed
    // using Yii::app()->params['paramName']
    'params' => require("params.php")
);
