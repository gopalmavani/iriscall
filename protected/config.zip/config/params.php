<?php
        return [
            'applicationName' => 'Iriscall',
            'appName' => 'IRIS',
            'applicationDescription' => '',
            'applicationTheme' => '',
            'giiPath' => '/var/www/cyc-01-dev.corecyclone.com/cbm',
            'basePath' => '/var/www/cyc-01-dev.corecyclone.com/cbm',
            'siteUrl' => 'http:/CBM',
            'templateCurlUrl' => 'http:',
            'mandatoryFields' => [
                'admin_id' => '1',
                'category_id' => '1',
            ],
            'FBUrl' => 'https://graph.facebook.com/oauth/access_token',
            'FBClientId' => 'client_id',
            'FBClientSecret' => 'client secret key',
            'FBGrantType' => 'client_credentials',
            'FBPageId' => 'page_id',
            'CBMAgentNumber' => 8917,
            'CBMMasterLogin' => 685,
            'MinimumNodeAmount' => 50,
            'NodeCost' => 5,
            'mt4ServiceUrl'=>'https://api.4xsolutions.com/Mt4manager/Accounts/',
            'SystemUserId' => 1,
            'CreditTransactionType' => 0,
            'DebitTransactionType' => 1,
            /*Ingenico Params*/
            'ingenicoUrl'=>'https://secure.ogone.com/ncol/test/orderstandard_utf8.asp',
            'PSPID'=>'deepak2499',
            //Pusher Details
            'NotificationAuthKey'=>'58b765c856595491cbdd',
            'NotificationSecretKey'=>'70ff87bc6ec429fdcc9c',
            'NotificationAppId'=>'533763',
            //Sum of all commission schemes
            'IdealTotalCommission'=>'0.74',
            //Affiliate Level Commission
            'LevelOneAffiliateCommission'=>'0.50',
            'LevelTwoAffiliateCommission'=>'0.25',
            //Slack notification channel
            'SlackNotificationChannel'=>'test_notification',
            'Group' => 'PHN_UK_250_EUR',
            //Transfer charges for payout
            'PayoutTransferCharges' => 5,
            'MinimumPayoutValue' => 50,
            //Stripe related details
            'StripePublishableKey' => 'pk_test_my2tWYBh2rSF5GkL5iaRWqxn',
            'StripeSecretKey' => 'sk_test_5f9d2LZu7NDy0bpTq25fjmGl',
            //PayPal related details
            'PayPalClientId' => 'ASup_1aK22hrCUPBC6JkomQdf4UIAHMDiQ_n2FXZ7sP934R3sZn9pVoKmKfEVzXr98XgDaWXGQfVHjIo',
            'PayPalSecretId' => 'EHICnrqddaRrocOPmqPCh4YwjWBfjQyTe3E9b08DsQJoKniT2qM1GVoNAF3GLNpzlw4A0HDLb8EIVT02',
            //Mail Chimp credentails
            'MailChimpURL' => 'https://us19.api.mailchimp.com/3.0/',
            'MailChimpEnglishListId' => '6f1b53bf97',
            'MailChimpDutchListId' => '82b2ee6985',
            'MailChimpAuthorizationId' => 'Bearer f0b434442ab96931de853f227296828e-us19',
            'ReserveWallet' => "Reserve Wallet",
            'UserWallet' => 'User Wallet',
            'WalletPendingTransactionStatus' => 0,
            'WalletApprovedTransactionStatus' => 2,
            'WalletRejectedTransactionStatus' => 3,
            'WalletTransactions' => 'Wallet Transactions',
            //Commission Transactions
            'CommissionTransactionsOne' => 'Commission Transactions-1',
            'CommissionTransactionsTwo' => 'Commission Transactions-2',
            //UTIT Agent Number
            'UTITAgentNumber' => '1887',
            'IsWalletNormalizationOngoing' => 0,
            //API token
            'APIToken' => 'Son)#Z]qew&Q$&@NQB3s>3Ogvn#pub',
            //Statalyse URL
            'StatalyseURL' => 'http://localhost/statalyse/public/api/register',
            //SSO URL
            'SSO_URL' => 'http://localhost/sso/public/',
            'maintenance' => 1,
            'NexiMaxAgent' => 8780,
            'UnityMaxAgent' => 8915,
            'TradingProductCategory' => 'Trading License',
            'CashbackProductCategory' => 'Cashback License',
            'cdr_username'=>'sagar',
            'cdr_password'=>'WaWCnMYSVtsFJ6W6'
        ];