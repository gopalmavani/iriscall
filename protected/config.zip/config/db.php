<?php
        return [
            'connectionString' => 'mysql:host=127.0.0.1;dbname=iriscall',
            'username' => 'root',
            'password' => '',
            'emulatePrepare' => 'cyl',
            'charset' => 'utf8'
        ];